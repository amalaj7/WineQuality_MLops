# To make it as a package


from setuptools import setup, find_packages

setup(
    name="src",
    version="0.0.1",
    description="its a wine Quality package package",
    author="amal",
    packages=find_packages(),
    license="MIT"
)

